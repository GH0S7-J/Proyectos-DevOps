﻿using CajeroAutomatico.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CajeroAutomatico.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Retiro()
        {
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Exit()
        {
            return View();
        }

        public ActionResult Dispensacion()
        {
            return View();
        }
    }
}

