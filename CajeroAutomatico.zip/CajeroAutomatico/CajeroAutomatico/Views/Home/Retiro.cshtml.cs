using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CajeroAutomatico.Views.Dispensador
{
    public class RetiroModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
