using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CajeroAutomatico.Views.Dispensador
{
    public class ConfiguracionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
