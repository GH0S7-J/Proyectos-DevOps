using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CajeroAutomatico.Views.Dispensador
{
    public class RetiroExitosoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
